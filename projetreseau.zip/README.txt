Le code est en version beta et présente des annotations :
	FIXME : Dysfonctionnement à corriger
	TODO : Fonctionnalité à implémenter
	TEMP : Morceau de code temporaire à changer dans la version finale